####
# CA APM AWS EPA PLugin
# Publishes EC2 Info, CloudWatch metrics and alarms as metrics to EPA
####
# CA APM AWS EPA PLugin
# Publishes EC2 Info, CloudWatch metrics, ELB, DDB, SNS, SQS, ALARM as metrics to EPA
# Publishes key attributes to ATC
#
# Though written in powershell it can query any kind of EC2 instance
#
# Author: Srikant Noorani @CA.com
# Date: Mar 2016
# 
# AWSGlobalVariables.ps1 - Contains Metrics that needs to be collected
# Users can modify this to add/delete metrics as they please
# 
####

####
# Global Variables
####
#$global:LogFile = ""
$global:DEBUG_ON = $false
$global:XML_CONFIG_OBJECT = $null

##Not USED
#$XML_FILE = "C:\pers\AWS\EPAgent\plugins\DefaultValues.xml"

####
# OOTB List of Key Metrics Queried from CW for EC2
# (metric name, Statistic, unit, Namespace)
# pls add your own if you have more
####
$EC2_METRIC_INFO_LIST = @(
	  ("CPUUtilization", "Average", "Percent", "AWS/EC2"),
	  ("DiskReadBytes", "Average", "Bytes", "AWS/EC2"),
	  ("DiskWriteBytes" , "Average", "Bytes", "AWS/EC2"),
	  ("NetworkIn", "Average", "Bytes", "AWS/EC2"),
	  ("NetworkOut", "Average", "Bytes", "AWS/EC2")
	) 


####
# OOTB List of Key Metrics Queried from CW for EBS
# (metric name, Statistic, unit, namespace)
# pls add your own if you have more
####
$EBS_METRIC_INFO_LIST = @(
	  ("VolumeReadBytes", "Average", "Bytes", "AWS/EBS"),
	  ("VolumeWriteBytes", "Average", "Bytes", "AWS/EBS"),
	  ("VolumeQueueLength" , "Average", "Count", "AWS/EBS"),
	  ("VolumeTotalReadTime", "Average", "Seconds", "AWS/EBS"),
	  ("VolumeTotalWriteTime", "Average", "Seconds", "AWS/EBS")
	)
	
	
####
# OOTB List of Key Metrics Queried from CW for SNS
# (metric name, Statistic, unit, namespace)
# pls add your own if you have more
####
$SNS_METRIC_INFO_LIST = @(
	  ("NumberOfNotificationsDelivered", "Sum", "Count", "AWS/SNS"),
	  ("NumberOfMessagesPublished", "Sum", "Count", "AWS/SNS"),
	  ("NumberOfNotificationsDelivered" , "Sum", "Count", "AWS/SNS"),
	  ("PublishSize", "Sum", "Count", "AWS/SNS")
	)

	
####
# OOTB List of Key Metrics Queried from CW for SQS
# (metric name, Statistic, unit, namespace)
# pls add your own if you have more
####
$SQS_METRIC_INFO_LIST = @(
	  ("NumberOfMessagesReceived", "Average", "Count", "AWS/SQS"),
	  ("NumberOfMessagesSent", "Average", "Count", "AWS/SQS"),
	  ("SentMessageSize" , "Average", "Bytes", "AWS/SQS"),
	  ("ApproximateNumberOfMessagesDelayed", "Average", "Count", "AWS/SQS")
	)
	
####
# OOTB List of Key Metrics Queried from CW for Dynamo DB
# (metric name, Statistic, unit, namespace)
# pls add your own if you have more
####
$DDB_METRIC_INFO_LIST = @(
	  ("ProvisionedReadCapacityUnits", "Sum", "Count", "AWS/DynamoDB"),
	  ("ThrottledRequests", "Sum", "Count", "AWS/DynamoDB"),
	  ("ConsumedReadCapacityUnits" , "Average", "Count", "AWS/DynamoDB"),
	  ("ConsumedWriteCapacityUnits", "Average", "Count", "AWS/DynamoDB"),
	  ("UserErrors" , "Average", "Count", "AWS/DynamoDB"),
	  ("SystemErrors", "Average", "Count", "AWS/DynamoDB")
	)

	
####
# OOTB List of Key Metrics Queried from CW for Elastic LB
# (metric name, Statistic, unit, namespace)
# pls add your own if you have more
####
$ELB_METRIC_INFO_LIST = @(
	  ("SurgeQueueLength", "Maximum", "Count", "AWS/ELB"),
	  ("Latency", "Average", "Seconds", "AWS/ELB"),
	  ("RequestCount" , "Average", "Count", "AWS/ELB")
	)



####
# OOTB List of Key Metrics Queried from CW for RDS
# (metric name, Statistic, unit, namespace)
# pls add your own if you have more
####
$RDS_METRIC_INFO_LIST = @(
	  ("CPUUtilization", "Average", "Bytes", "AWS/RDS"),
	  ("DatabaseConnections", "Average", "Count", "AWS/RDS"),
	  ("DiskQueueDepth" , "Average", "Count", "AWS/RDS"),
	  ("ReadLatency" , "Average", "Seconds", "AWS/RDS"),
	  ("WriteLatency" , "Average", "Seconds", "AWS/RDS")
	)
	
		
####
# Only monitor those EC2 instances that have apm agents on them 
# meaning agents monitoring app
####	
$MONITOR_APM_AGENT_EC2_ONLY = $true	
    
    
####
# Publish APM Team Center Attributes OR not
####
$PUBLISH_TO_ATC = $true


####
# Publish Metrics (EC2, EC2, ELB etc) to EM through EPA
####
$PUBLISH_METRICS = $true


####
# USER Defined Do Not Publish List
# Pls add string items comma separated. 
# @("item1", "item2", "item3" )
####
$ATC_USER_DEFINED_DO_NOT_PUBLISH_LIST = @()

####


####
# User Defined Attributes to be published on ATC
# add the following if you want to publish arbitrary 
# attribute name value pair to all vertices
# for e.g. releaseNumber = 10.1_Update4 then add it to the 
# following variable and uncomment
#E.g $USER_ATC_ATTRIB_LIST = @{"MyAttrbName = "MyAttribValue"}
####


# Some Instance ID to ATC Attrib Mapping that script can use 
# to filter vertices for publishing custom attribs
# Feel free to change as per need
# By default maps instance id to hostname based instance private IP to agent IP map
####
#function getUserDefinedAttribFilter ($INSTANCE_ID) {
#	$HOSTNAME = [System.Net.DNS]::GetHostEntry((Get-EC2Instance -Instance $INSTANCE_ID).RunningInstance[0].PrivateIpAddress).HostName
#	
#	return @{ hostname = $HOSTNAME }
#}

####
# getUserDefinedAttribFilter returns a map of instance ID to hostname
####
function getUserDefinedAttribFilter ($INSTANCES, $EM_HOST, $EM_PORT, $EM_LOGIN, $EM_PASSWORD) {
	
	#write-host "1host $EM_HOST, port $EM_PORT, $EM_LOGIN, $EM_PASSWORD"
	
	$ATTRIBUTE_FILTER_MAP = @{}	
	$IP_TO_HOSTNAME_MAP = buildIPToHostNameMap $EM_HOST $EM_PORT $EM_LOGIN $EM_PASSWORD
			
	#write-host "in filter function"
	foreach ( $INSTANCE_ID in $INSTANCES ) {
		$IP = $INSTANCE_ID.RunningInstance[0].PrivateIpAddress
		
		if ( $IP -ne $null ) {

			$HOSTNAME = $IP_TO_HOSTNAME_MAP.$IP
			
			if ( -Not [string]::IsNullOrEmpty($HOSTNAME)) {
				
				$INSTANCE = $INSTANCE_ID.RunningInstance[0].InstanceId
				#write-host " Filter is Hostname is $HOSTNAME, IP is $IP, instnace is $INSTANCE"
				$ATTRIBUTE_FILTER_MAP = $ATTRIBUTE_FILTER_MAP + @{ $INSTANCE = @{"hostname" = $HOSTNAME } }
			}
		}
	}

		return $ATTRIBUTE_FILTER_MAP
}

#Query EM to build IP to hostname map
function buildIPToHostNameMap( $EM_HOST, $EM_PORT, $EM_LOGIN, $EM_PASSWORD) {
	
	$IP_TO_HOSTNAME_MAP = @{}

	#write-host "2host $EM_HOST, port $EM_PORT, $EM_LOGIN, $EM_PASSWORD,"
	
	$AGENT_LIST=java -Xmx128M -Duser="$EM_LOGIN" -Dpassword="$EM_PASSWORD" -Dhost="$EM_HOST" -Dport="$EM_PORT" -jar $CLWORKSTATION_JAR_PATH "get historical data from agents matching `".*`" and metrics matching `"Host:IP Address`" for past 1 minutes with frequency of 60 seconds"
	
	$AGENT_LIST = $AGENT_LIST| Get-Unique

	$COUNT=0

	foreach ( $AGENT in $AGENT_LIST ) {

		if ( $COUNT -gt  1 ) {
		
			$AGENT_ARRAY = $AGENT.split(",")
			
			$HOSTNAME = $AGENT_ARRAY[1]
			$AGENT_IP = $AGENT_ARRAY[$AGENT_ARRAY.lenght - 2]
			
			 #write-host "map is $HOSTNAME IP $AGENT_IP"
			 
			if ( -Not $IP_TO_HOSTNAME_MAP.ContainsKey($AGENT_IP ) ) {
				$IP_TO_HOSTNAME_MAP = $IP_TO_HOSTNAME_MAP + @{ $AGENT_IP = $HOSTNAME  }
			}
			
			
		}
		
		$COUNT= $COUNT + 1
	   
	}
	
	return $IP_TO_HOSTNAME_MAP
}