# CA APM AWS Field Pack (1.0.0)

## Description
This field pack allows monitoring of various services belonging to AWS. This field pack is written in Windows PowerShell and can be deployed on any windows box as long as it has access to AWS.  

It publishes both EPA metrics as well as publishes key attributes to ATC vertices


## Short Description
This field pack allows monitoring of various services belonging to AWS.

## APM version
Tested with APM 10.1 and Should work with any APM agent 10.0+.

## Supported third party versions
Need Powershell 2.0+ and AWS Tools for Windows PowerShell: 3.1.76.0

## Limitations
 none that we know off


## License
[Eclipse Public License - v 1.0](LICENSE)


# Installation Instructions

Pls follow the pdf in CAAPMAWSMonitoringFieldPack.doc folder


# Usage Instructions

Pls follow the pdf in CAAPMAWSMonitoringFieldPack.doc folder


## Support
This document and associated tools are made available from CA Technologies as examples and provided at no charge as a courtesy to the CA APM Community at large. This resource may require modification for use in your environment. However, please note that this resource is not supported by CA Technologies, and inclusion in this site should not be construed to be an endorsement or recommendation by CA Technologies. These utilities are not covered by the CA Technologies software license agreement and there is no explicit or implied warranty from CA Technologies. They can be used and distributed freely amongst the CA APM Community, but not sold. As such, they are unsupported software, provided as is without warranty of any kind, express or implied, including but not limited to warranties of merchantability and fitness for a particular purpose. CA Technologies does not warrant that this resource will meet your requirements or that the operation of the resource will be uninterrupted or error free or that any defects will be corrected. The use of this resource implies that you understand and agree to the terms listed herein.

Although these utilities are unsupported, please let us know if you have any problems or questions by adding a comment to the CA APM Community Site area where the resource is located, so that the Author(s) may attempt to address the issue or question.

Unless explicitly stated otherwise this field pack is only supported on the same platforms as the APM core agent. See [APM Compatibility Guide](http://www.ca.com/us/support/ca-support-online/product-content/status/compatibility-matrix/application-performance-management-compatibility-guide.aspx).

### Support URL
*Mandatory for the APM marketplace*
*if closed source, not supported, then create an empty github.com repository, and link github issue tracker as a courtesy*
https://github-isl-01.ca.com/noosr03/fieldpack.ca-apm-aws/issues

## Categories



# Change log
Changes for each version of the field pack.

Version | Author | Comment
--------|--------|--------
1.0 | Srikant Noorani| First version of the field pack.
